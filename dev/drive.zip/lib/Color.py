from lib.camera import *
from lib.controller import *

def color_callback(event):
        pass


color_detector.add_detection_listener(color_callback)


